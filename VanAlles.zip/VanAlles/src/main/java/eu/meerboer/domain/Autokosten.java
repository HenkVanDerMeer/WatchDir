package eu.meerboer.domain;

import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.time.LocalDate;

@Data
@Entity
public class Autokosten {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @DateTimeFormat(pattern = "dd/MM/yyyy")
    private LocalDate datum = LocalDate.now();
    private int kmStand;
    @Column(columnDefinition = "DECIMAL(5,2)")
    private float liter;
    @Column(columnDefinition = "DECIMAL(5,3)")
    private float literPrijs;
}
