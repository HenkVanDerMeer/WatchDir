package eu.meerboer.domain;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AfstandRepository extends JpaRepository<Afstand, Integer> {

    List<Afstand> findAllByOrderByDatumDesc();
    Afstand findFirstByOrderByDatumDesc();
}
