package eu.meerboer.domain;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AutokostenRepository extends JpaRepository<Autokosten, Integer> {

    List<Autokosten> findAllByOrderByDatumDesc();
}
