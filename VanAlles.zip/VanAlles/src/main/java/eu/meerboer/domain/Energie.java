package eu.meerboer.domain;

import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.time.LocalDate;

@Data
@Entity
@Table(uniqueConstraints = @UniqueConstraint(columnNames = "datum"))
public class Energie {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @DateTimeFormat(pattern = "dd/MM/yyyy")
    private LocalDate datum = LocalDate.now().plusDays(1);
    private short electraDag;
    private short electraDagTerug;
    private short electraNacht;
    private short electraNachtTerug;
    @Column(columnDefinition = "DECIMAL(8,3)")
    private float gas;
}
