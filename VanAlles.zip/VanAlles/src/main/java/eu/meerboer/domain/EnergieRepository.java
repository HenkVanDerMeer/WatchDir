package eu.meerboer.domain;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EnergieRepository extends JpaRepository<Energie, Integer> {

    List<Energie> findAllByOrderByIdDesc();
}
