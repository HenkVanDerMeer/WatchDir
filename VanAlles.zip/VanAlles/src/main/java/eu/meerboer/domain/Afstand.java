package eu.meerboer.domain;

import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.time.LocalDate;

@Data
@Entity
@Table(uniqueConstraints = @UniqueConstraint(columnNames = "datum"))
public class Afstand {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private float afstandKm = 0.0f;
    @DateTimeFormat(pattern = "dd/MM/yyyy")
    private LocalDate datum = LocalDate.now();
    private short stappen = 0;

    private Afstand() {}

    public Afstand(LocalDate datum) {
        this.datum = datum;
    }
}
