package eu.meerboer.domain;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface GewichtRepository extends JpaRepository<Gewicht, Integer> {

    List<Gewicht> findAllByOrderByDatumTijdDesc();
}
