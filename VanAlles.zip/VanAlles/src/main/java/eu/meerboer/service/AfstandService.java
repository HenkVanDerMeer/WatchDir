package eu.meerboer.service;

import eu.meerboer.domain.Afstand;
import eu.meerboer.domain.AfstandRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

@Slf4j
@Service
public class AfstandService {

    @Autowired
    AfstandRepository afstandRepository;

    public void createUntilToday() {
        LocalDate laatsteDatum = afstandRepository.findFirstByOrderByDatumDesc().getDatum();
        while (laatsteDatum.isBefore(LocalDate.now())) {
            laatsteDatum = laatsteDatum.plusDays(1);
            Afstand afstand = new Afstand(laatsteDatum);
            afstandRepository.save(new Afstand(laatsteDatum));
        }
    }
}
