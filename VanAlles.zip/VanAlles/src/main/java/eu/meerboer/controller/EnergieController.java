package eu.meerboer.controller;

import eu.meerboer.domain.Energie;
import eu.meerboer.domain.EnergieRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.validation.Valid;

@Slf4j
@Controller
@RequestMapping("/energie")
public class EnergieController {

    @Autowired
    private EnergieRepository energieRepository;

    @GetMapping("/")
    public String eneList(Model model) {
        model.addAttribute("meterstanden", energieRepository.findAllByOrderByIdDesc());
        return "energie/ene-list";
    }

    @GetMapping("/ene-create")
    public String eneCreate(Energie energie, Model model) {
        model.addAttribute("meterstand", energie);
        return "energie/ene-create";
    }

    @PostMapping("/ene-save")
    public String eneSave(@Valid Energie energie, BindingResult result, Model model) {
        log.debug("energie: " + energie);
        if(result.hasErrors()) {
            log.error("{} fout(en) bij opslaan van meterstand", result.getErrorCount());
            return "energie/ene-create";
        }
        energieRepository.save(energie);
        return "redirect:/energie/";
    }

    @GetMapping("/ene-update/{id}")
    public String eneUpdate(@PathVariable("id") int id, Model model) {
        Energie energie = energieRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid Energie Id:" + id));
        model.addAttribute("meterstand", energie);
        return "energie/ene-update";
    }

    @PostMapping("/ene-update/{id}")
    public String eneUpdate(@PathVariable("id") int id, @Valid Energie energie, BindingResult result, Model model) {
        log.debug("energie: " + energie);
        if (result.hasErrors()) {
            log.error("{} fout(en) bij opslaan van meterstand", result.getErrorCount());
            energie.setId(id);
            return "energie/ene-update";
        }
        energieRepository.save(energie);
        return "redirect:/energie/";
    }
}
