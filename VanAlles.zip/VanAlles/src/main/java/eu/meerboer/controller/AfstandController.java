package eu.meerboer.controller;

import eu.meerboer.domain.Afstand;
import eu.meerboer.domain.AfstandRepository;
import eu.meerboer.service.AfstandService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.validation.Valid;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Slf4j
@Controller
@RequestMapping("/afstand")
public class AfstandController {

    @Autowired
    private AfstandRepository afstandRepository;

    @Autowired
    private AfstandService afstandService;

    @GetMapping("/")
    public String afsList(Model model) {
        String vandaag = LocalDate.now().format(DateTimeFormatter.ofPattern("dd MMM"));
        model.addAttribute("afstanden", afstandRepository.findAllByOrderByDatumDesc());
        model.addAttribute("tmvandaag", "t/m " + vandaag);
        return "afstand/afs-list";
    }

    @GetMapping("/afs-create")
    public String afsCreate(Afstand afstand) {
        return "afstand/afs-create";
    }

    @GetMapping("/afs-create-tm-vandaag")
    public String afsCreateTmVandaag(Model model, Afstand afstand) {
        String vandaag = LocalDate.now().format(DateTimeFormatter.ofPattern("dd MMM"));
        afstandService.createUntilToday();
        model.addAttribute("afstanden", afstandRepository.findAllByOrderByDatumDesc());
        model.addAttribute("tmvandaag", "t/m " + vandaag);
        return "afstand/afs-list";
    }

    @PostMapping("/afs-save")
    public String afsSave(@Valid Afstand afstand, BindingResult result, Model model) {
        log.info("afstand: " + afstand);
        log.info("Fout: " + result.hasErrors());
        if(result.hasErrors()) {
            return "afstand/afs-create";
        }
        afstandRepository.save(afstand);
        return "redirect:/afstand/";
    }

    @GetMapping("/afs-update/{id}")
    public String afsUpdate(@PathVariable("id") int id, Model model) {
        Afstand afstand = afstandRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid afstand Id:" + id));
        log.info("GET afs-update: {}", afstand);
        model.addAttribute("afstand", afstand);
        return "afstand/afs-update";
    }

    @PostMapping("/afs-update/{id}")
    public String afsUpdate(@PathVariable("id") int id, @Valid Afstand afstand, BindingResult result, Model model) {
        log.info("POST afs-update id: {}", id);
        log.info("POST afs-update: {}", afstand);
        log.info("Error: " + result.hasErrors());
        if (result.hasErrors()) {
            log.info("Settinng id to {}", id);
            afstand.setId(id);
            log.info("id set to {}", afstand.getId());
            return "afstand/afs-update";
        }
        afstandRepository.save(afstand);
        return "redirect:/afstand/";
    }
}
