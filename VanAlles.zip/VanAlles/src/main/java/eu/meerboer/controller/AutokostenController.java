package eu.meerboer.controller;

import eu.meerboer.domain.Autokosten;
import eu.meerboer.domain.AutokostenRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.validation.Valid;

@Slf4j
@Controller
@RequestMapping("/autokosten")
public class AutokostenController {

    @Autowired
    AutokostenRepository autokostenRepository;

    @GetMapping("/")
    public String autList(Model model) {
        model.addAttribute("autokosten", autokostenRepository.findAllByOrderByDatumDesc());
        return "autokosten/aut-list";
    }

    @GetMapping("/aut-create")
    public String autCreate(Autokosten autokosten) {
        return "autokosten/aut-create";
    }

    @PostMapping("/aut-save")
    public String autSave(@Valid Autokosten autokosten, BindingResult result, Model model) {
        if(result.hasErrors()) {
            return "autokosten/aut-create";
        }
        autokostenRepository.save(autokosten);
        return "redirect:/autokosten/";
    }

    @GetMapping("/aut-update/{id}")
    public String autUpdate(@PathVariable("id") int id, Model model) {
        Autokosten autokosten = autokostenRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid autokosten Id:" + id));
        model.addAttribute("autokosten", autokosten);
        return "autokosten/aut-update";
    }

    @PostMapping("/aut-update/{id}")
    public String autUpdate(@PathVariable("id") int id, @Valid Autokosten autokosten, BindingResult result, Model model) {
        if (result.hasErrors()) {
            autokosten.setId(id);
            return "autokosten/aut-update";
        }
        autokostenRepository.save(autokosten);
        return "redirect:/autokosten/";
    }
}
