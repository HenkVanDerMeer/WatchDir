package eu.meerboer.controller;

import eu.meerboer.domain.Gewicht;
import eu.meerboer.domain.GewichtRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.validation.Valid;
import java.time.format.DateTimeFormatter;

@Slf4j
@Controller
@RequestMapping("/gewicht")
public class GewichtController {

    @Autowired
    private GewichtRepository gewichtRepository;

    @GetMapping("/")
    public String gewList(Model model) {
        model.addAttribute("gewichten", gewichtRepository.findAllByOrderByDatumTijdDesc());
        return "gewicht/gew-list";
    }

    @GetMapping("/gew-create")
    public String gewCreate(Gewicht gewicht) {
        return "gewicht/gew-create";
    }

    @PostMapping("/gew-save")
    public String gewSave(@Valid Gewicht gewicht, BindingResult result, Model model) {
        log.info("gewicht: " + gewicht);
        log.info("Fout: " + result.hasErrors());
        if(result.hasErrors()) {
            return "gewicht/gew-create";
        }
        gewichtRepository.save(gewicht);
        return "redirect:/gewicht/";
    }

    @GetMapping("/gew-update/{id}")
    public String gewUpdate(@PathVariable("id") int id, Model model) {
        DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        DateTimeFormatter timeFormat = DateTimeFormatter.ofPattern("hh:mm");
        Gewicht gewicht = gewichtRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid gewicht Id:" + id));
        log.info("Datum: {}", gewicht.getDatumTijd().format(dateFormat));
        log.info("Tijd: {}", gewicht.getDatumTijd().format(timeFormat));
        model.addAttribute("gewicht", gewicht);
        model.addAttribute("datum", gewicht.getDatumTijd().format(dateFormat));
        model.addAttribute("tijd", gewicht.getDatumTijd().format(timeFormat));
        return "gewicht/gew-update";
    }

    @PostMapping("/gew-update/{id}")
    public String gewUpdate(@PathVariable("id") int id, @Valid Gewicht gewicht, BindingResult result, Model model) {
        log.info("gew-update: " + gewicht);
        log.info("Error: " + result.hasErrors());
        if (result.hasErrors()) {
            gewicht.setId(id);
            return "gewicht/gew-update";
        }
        gewichtRepository.save(gewicht);
        return "redirect:/gewicht/";
    }
}
